# Basic JS

This repository contains basic exercises to get familiar with basic javascript.

This repository is using `yarn` as the main package manager.

To install dependencies:

```
yarn install
```

To run the examples:

```
yarn start
```
