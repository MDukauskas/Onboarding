# Slider

## Goal:

Create Q&A accordion 

## Requirements

- Accordion to load data from JSON file
- Accordion title should toggle color when Active/inActive

## Bonus

- Accordion has animations when opened/closed
- some tests are written to check accordion functionality
