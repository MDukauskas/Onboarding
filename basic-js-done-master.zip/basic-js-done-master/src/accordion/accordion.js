import dataJSON from './data.json'

export class accordion {
  constructor() {
    const data = dataJSON
    const accordion = document.getElementById('accordion')
    this.formatAccordionItems(data, accordion)
  }

  formatAccordionItems(data, accordion) {
    data.accordionData.forEach((item, index) => {
      accordion.appendChild(this.buildAccordionSection(index, item.header, item.content))
    })
  }

  buildAccordionSection(identifier, headerText, contentText) {
    const section = document.createElement('div')
    section.classList.add('accordion__section')
    const header = document.createElement('div')
    header.setAttribute('id', `accordion__item--${identifier}`)
    header.classList.add(`accordion__header`)
    header.innerText = headerText
    const content = document.createElement('div')
    content.classList.add('accordion__content')
    content.innerText = contentText
    section.appendChild(header)
    section.appendChild(content)
    header.addEventListener('click', () => { this.toggleItem(content)})
    return section
  }

  openItem(item) {
    item.classList.add('accordion__content--active')
  }

  closeItem(item) {
    item.classList.remove('accordion__content--active')
  }

  toggleItem(item) {
    console.log(item.classList)
    item.classList.contains('accordion__content--active') ? this.closeItem(item) : this.openItem(item)
  }
}
