import style from "./main.scss";
import { accordion } from './accordion'

const acc = new accordion()