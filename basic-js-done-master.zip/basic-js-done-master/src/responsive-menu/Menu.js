export class Menu {
  container = null;
  active = false;
  constructor(container) {
    this.container = container;
    this.container
      .getElementsByClassName("tlsft-menu-burger")[0]
      .addEventListener("click", () => this.setToggleMenu());
    this.container
      .getElementsByClassName("tlsft-menu-close")[0]
      .addEventListener("click", () => this.setToggleMenu());
  }

  setToggleMenu = () => {
    if (this.active) {
      this.container.classList.remove("active");
    } else {
      this.container.classList.add("active");
    }
    this.active = !this.active;
  };
}
