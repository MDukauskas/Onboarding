export class Slider {
	constructor(count) {
		this.activeSlide = 0
		this.count = count
		this.timer = undefined
		this.rotateSlides()
	}

	setActiveSlide(index) {
		if (index >= this.count) {
			index = 0
		}
		if (index < 0) {
			index = this.count - 1
		}

		this.activeSlide = index
		this.rotateSlides()
	}

	nextSlide = () => {
		this.setActiveSlide(++this.activeSlide)
	}

	previousSlide = () => {
		this.setActiveSlide(--this.activeSlide)
	}

	rotateSlides() {
		clearTimeout(this.timer)
		this.timer = setTimeout(this.nextSlide, 1000)
	}
}

export class DOMSlider extends Slider {
	constructor(container) {
		const slides = container.getElementsByClassName('slide')
		super(slides.length)

		this.container = container
		this.slides = slides
		this.slidesImages = Array.from(this.slides).map(slide => {
			return slide.getElementsByClassName('slide__image')[0]
		})
		container.getElementsByClassName('slider__button--previous')[0].addEventListener('click', this.previousSlide)
		container.getElementsByClassName('slider__button--next')[0].addEventListener('click', this.nextSlide)

		this.initThumbnails()
		this.setActiveSlide(0)
	}

	setActiveSlide(index) {
		super.setActiveSlide(index)

		for (let i = 0; i < this.count; i++) {
			if (i === this.activeSlide) {
				this.slides[i].classList.add('active')
				this.thumbnails[i].classList.add('active')
			} else {
				this.slides[i].classList.remove('active')
				this.thumbnails[i].classList.remove('active')
			}
		}
	}

	initThumbnails() {
		this.thumbnails = []
		const thumbnailContainer = this.container.getElementsByClassName('slider__thumbnails')[0]

		for (let i = 0; i < this.slidesImages.length; i++) {
			const thumbnail = document.createElement('img')
			thumbnail.src = this.slidesImages[i].src
			thumbnail.classList.add('thumbnail')
			thumbnail.addEventListener('click', () => this.setActiveSlide(i))
			thumbnailContainer.appendChild(thumbnail)
			this.thumbnails.push(thumbnail)
		}
	}
}
