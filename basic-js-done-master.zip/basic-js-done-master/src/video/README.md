##Responsive video

###Goal:
Embed a video from a YouTube in a iframe and make it responsive.

###Steps:
* Set the necessary headers to make page responsive
* Have a centered  content container with a max width of 1224px
* Create a wrapper for an iframe
* Create an iframe which would let you embed video from YouTube
  (source link: https://www.youtube.com/embed/wa6AMLpV0-c)
* Make the wrapper responsive, keeping the aspect ratio of 16:9
* Make it look as close to the provided design as possible