import style from "./main.scss";

console.log("Video initialised");